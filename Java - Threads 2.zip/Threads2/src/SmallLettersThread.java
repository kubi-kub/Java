import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SmallLettersThread extends Thread {
    Text Content;

    public SmallLettersThread(Text c) {

        Content = c;
    }

    public void run() {
        {
            Content = Content.toLowerCase();
            System.out.println("Final text: " + Content.toString());
            List<Character> vowels = Arrays.asList('a', 'e', 'i', 'o', 'u', 'y');
            int count = 0;
            for(int i = 0; i < Content.length(); i ++) {
                char ch = Content.charAt(i);
                if(vowels.contains(ch)) {
                    count++;
                }
            }
            System.out.println("Number of vowels: " + count);
        }
        System.out.println("I am finished. Wake up!");
    }

}
/*
    public void run(){
        synchronized (this){
            word=help.getContent();
            word=word.toLowerCase(Locale.ROOT);
            System.out.println("SmallLetters: "+word);
            for(int i =0; i<word.length();i++){
                if(vow.contains(word.charAt(i))){
                    s+=1;
                }
            }
            System.out.println("Number of vowels: "+s);

            Text.setContent(word);
            notify();
        }
    }
*/