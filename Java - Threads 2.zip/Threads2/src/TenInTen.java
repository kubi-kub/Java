import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class TenInTen {
    public static void main(String[] args) throws InterruptedException {
        ArrayList<String> lines = new ArrayList<String>();
        lines = ReadTextFile();
        String ans = "yes";
        int lineNo = 0;
        Scanner answer = new Scanner(System.in);
        while(ans.equals("yes")) {
            System.out.print("Would you like to start? (yes or no): ");
            ans = answer.next();

            switch (ans) {
                case "yes":
                    System.out.println("This is where the fun begins... ;)");
                    String line = lines.get(lineNo);
                    System.out.print(line);
                    TimeUnit.SECONDS.sleep(10);
                    for(int i = 0; i < line.length(); i++) {
                        System.out.print((char)8);
                    }
                    AnswerThread at = new AnswerThread();
                    at.kickOff();
                    at.start();
                    synchronized(at){
                        try{
                            at.wait(10000);
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                    at.finish();
                    at.join();
                    TimeUnit.MILLISECONDS.sleep(500);
                    ArrayList<String> words = at.getAnswer();

                    int result = 0;
                    for(int i = 0; i < words.size(); i++) {
                        if(line.contains(words.get(i))) {
                            result++;
                        }
                    }
                    System.out.println("Ilość prawidłowych odpowiedzi: " + result);

                    lineNo++;
                    break;

                case "no":
                    System.out.println("No to cześć!");
                    break;

                default:
                    System.out.println("Answer! DEW IT!");
            }
        }
    }

    static ArrayList<String> ReadTextFile(){
        ArrayList<String> lines = new ArrayList<String>();
        try {
            File myObj = new File("C:\\Users\\48691\\Desktop\\WordsToMemorize.txt");
            Scanner myReader = new Scanner(myObj);
            while(myReader.hasNextLine()) {
                String data = myReader.nextLine();
                lines.add(data);
            }
            myReader.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("An error occured");
            e.printStackTrace();
        }
        return(lines);
    }
}
