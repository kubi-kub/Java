import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Scanner;

public class AnswerThread extends Thread{
    ArrayList<String> answer;
    boolean doit;

    public AnswerThread() {
        answer = new ArrayList<String>();
    }

    public void run(){
        String ans;
        Scanner reader = new Scanner(System.in);
        System.out.println("Spróbuj napisać zapamiętane słowa! Masz 10 sekund!");
        while(doit) {
            ans = reader.next();
            if (doit){
                answer.add(ans);
            }
            else{
                System.out.println("Nie zaliczam: " + ans);
            }
        }
        synchronized(this){
            try{
                this.notify();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public ArrayList<String> getAnswer(){
        return answer;
    }

    public void kickOff(){
        doit = true;
    }

    public void finish(){
        doit = false;
    }
}
