import java.util.Arrays;
import java.util.List;
public class NoVowelsThread extends Thread {
    Text Content;

    public NoVowelsThread(Text c) {
        Content = c;
    }

    public synchronized void run() {
        String finalString = "";
        Content = Content.toLowerCase();
        List<Character> vowels = Arrays.asList('a', 'e', 'i', 'o', 'u', 'y');
        for(int i = 0; i < Content.length(); i ++) {
            char ch = Content.charAt(i);
            if(vowels.contains(ch)) {
                finalString += " ";
            }
            else {
                finalString += ch;
            }
        }
        Content = new Text(finalString);
        System.out.println(Content.toString());
    }
}
/*
    public void run(){
        synchronized (this) {
            word = help.getContent();
            System.out.println(word);
            word = word.replaceAll("([a,e,y,u,i,o])", " ");
            System.out.println("NoVowels:" + word);
            Text.setContent(word);
            notify();
        }
    }
 */