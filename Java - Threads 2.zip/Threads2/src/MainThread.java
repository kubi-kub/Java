public class MainThread {
    public static void main(String[] args) throws Exception {
        Text t = new Text("AeuioJJnjkOnlknkjhknkIHOOOOOOOOOOOFGHEiunFeRUOI");
        SmallLettersThread slt = new SmallLettersThread(t);
        NoVowelsThread nvt = new NoVowelsThread(t);
        System.out.println("Initial text: " + t.content);

        slt.start();
        nvt.start();
        synchronized(nvt){
            nvt.wait();
        }
        slt.join();
        synchronized (slt) {
            slt.notify();
        }
        nvt.join();

        System.out.println("THE END");
    }
}

/*
slT.start();
synchronized (slT){
        slT.wait();
        }
        nvT.start();
synchronized (nvT){
        nvT.wait();
        }
        System.out.println("the endo");
*/