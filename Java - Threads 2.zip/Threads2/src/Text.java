import java.util.Locale;

public class Text {
    String content;

    public Text(String c) {

        content = c;
    }

    public Text toLowerCase() {

        return new Text(content.toLowerCase(Locale.ROOT));
    }

    public int length() {

        return content.length();
    }

    public char charAt(int i) {

        return content.charAt(i);
    }

    public String toString() {

        return content;
    }
}
