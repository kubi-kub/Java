import java.util.ArrayList;
public class Main2 {
    public static void main(String args[]) throws InterruptedException {
        ArrayList initialArrL = new ArrayList(20);
        initialize(initialArrL);
        System.out.println("Initial Array: " + initialArrL);
        SortIntegersThread sit = new SortIntegersThread(initialArrL);
        SortStringsThread sst = new SortStringsThread(initialArrL);
        sit.start();
        sst.start();
        sit.join();
        sst.join();
        ArrayList finalArray = new ArrayList();
        for (int i = 0; i < sit.getSortedArrL().size(); i++){
            finalArray.add(sit.getSortedArrL().get(i));
        }
        for (int i = 0; i < sst.getSortedArrL().size(); i++){
            finalArray.add(sst.getSortedArrL().get(i));
        }
        System.out.println("Final Array: " + finalArray);
    }

    static void initialize(ArrayList initialArrL){
        initialArrL.add(1);
        initialArrL.add('a');
        initialArrL.add('d');
        initialArrL.add(5);
        initialArrL.add('e');
        initialArrL.add(3);
        initialArrL.add('h');
        initialArrL.add(2);
        initialArrL.add('i');
        initialArrL.add(4);
        initialArrL.add('j');
        initialArrL.add(7);
        initialArrL.add(6);
        initialArrL.add('g');
        initialArrL.add(9);
        initialArrL.add('f');
        initialArrL.add(10);
        initialArrL.add('c');
        initialArrL.add(8);
        initialArrL.add('b');
    }
}
