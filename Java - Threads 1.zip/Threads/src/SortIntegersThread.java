import java.util.ArrayList;
import java.util.Arrays;

public class SortIntegersThread extends Thread {
    ArrayList mixedArrL;
    ArrayList<Integer> sortedArrL;
    public SortIntegersThread(ArrayList arrL){
        mixedArrL = arrL;
        sortedArrL = new ArrayList<>();
    }

    public void run() {
        for(int i = 0; i < mixedArrL.size(); i++) {
            if (isInteger(mixedArrL.get(i))){
                sortedArrL.add((int)mixedArrL.get(i));
            }
        }
        sortedArrL.sort(null);
    }

    public ArrayList getSortedArrL(){
        return sortedArrL;
    }

    static boolean isInteger(Object o) {
        try {
            int i = (int)o;
            return true;
        }
        catch(Exception e) {
            return false;
        }
    }
}
