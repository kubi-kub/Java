public class ThreadsBasics {
    public static void main(String[] args) {
        MyThread1 mt1 = new MyThread1();
        mt1.start();

        MyThread2 mt2 = new MyThread2();
        Thread t = new Thread(mt2);
        t.start();
    }
}
