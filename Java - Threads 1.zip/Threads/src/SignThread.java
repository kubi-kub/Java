import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class SignThread extends Thread {
    static Date data;
    static String[] znaki = new String[]{"baran", "byk", "bliźnięta", "rak", "lew", "panna", "waga", "skorpion", "strzelec", "koziorożec", "wodnik", "ryby"};
    static String[] daty = new String[]{"21.03-20.04", "21.04-21.05", "22.05-21.06", "22.06-22.07", "23.07-23.08", "24.08-22.09", "23.09-22.10", "23.10-22.11", "23.11-21.12", "22.12-19.01", "20.01-18.02", "19.02-20.03"};

    public SignThread(Date dt) {
        data = dt;
    }

    public void run() {
        System.out.println("Your sign is: " + GetSign());
    }

    public static String GetSign() {
        LocalDate ldate = data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        int dd = ldate.getDayOfMonth();
        int mm = ldate.getMonthValue();
        String sm = String.format("%02d", mm);
        for (int i = 0; i < daty.length; i++) {
            String m1 = daty[i].substring(3, 5);
            String m2 = daty[i].substring(9, 11);
            if (m1.equals(sm)) {
                int d = Integer.parseInt(daty[i].substring(0, 2));
                if (dd >= d) {
                    return (znaki[i]);
                }
            }
            if (m2.equals(sm)) {
                int d = Integer.parseInt(daty[i].substring(6, 8));
                if (dd <= d) {
                    return (znaki[i]);
                }
            }
        }

        return ("");
    }
}
