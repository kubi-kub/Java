public class MaxThread extends Thread {
    int numbers[];

    public MaxThread(int[] nums) {
        numbers = nums;
    }

    public void run(){
        System.out.println("Waiting 1 second...");
        wait(1);
        System.out.println("Maximum Value = " + getMaxValue(numbers));
    }

    public static int getMaxValue(int[] numbers) {
        int maxValue = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > maxValue) {
                maxValue = numbers[i];
            }
        }
        return maxValue;
    }

    public void wait(int sec) {
        try {
            Thread.currentThread().sleep(sec*1000);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
