import java.util.Arrays;
import java.lang.*;
public class Main {
    public static void main(String args[]) throws InterruptedException {
        int numbers[] = {1, 5, -9, 12, -3, 89, 18, 23, 4, -6};

        /*
        System.out.println("Waiting 1 second...");
        Thread.sleep(1000);
        System.out.println("Minimum Value = " + getMinValue(numbers));

        System.out.println("Waiting 1 second...");
        Thread.sleep(1000);
        System.out.println("Maximum Value = " + getMaxValue(numbers));
        System.out.println("time in nanoseconds = " + System.nanoTime());
         */

        long startTime = System.nanoTime();
        System.out.println("time in nanoseconds = " + startTime);
        MinThread mt1 = new MinThread(numbers);
        mt1.start();

        MaxThread mt2 = new MaxThread(numbers);
        mt2.start();

        while (mt1.isAlive() || mt2.isAlive()){
            Thread.sleep(10);
        }
        if (mt1.isAlive()){
            System.out.println("Wątek mt1 działa");
        }
        else {
            System.out.println("Wątek mt1 nie działa");
        }

        long finishTime = System.nanoTime();
        System.out.println("time in nanoseconds = " + finishTime);
        System.out.println(finishTime - startTime);

    }

    public static int getMaxValue(int[] numbers) {
        int maxValue = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > maxValue) {
                maxValue = numbers[i];
            }
        }
        return maxValue;
    }

    public static int getMinValue(int[] numbers) {
        int minValue = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < minValue) {
                minValue = numbers[i];
            }
        }
        return minValue;
    }
}
