import java.util.ArrayList;
public class SortStringsThread extends Thread{
    ArrayList mixedArrL;
    ArrayList<Character> sortedArrL;

    public SortStringsThread(ArrayList arrL) {
        mixedArrL = arrL;
        sortedArrL = new ArrayList<>();
    }

    public void run() {
        for(int i = 0; i < mixedArrL.size(); i++) {
            if (!isInteger(mixedArrL.get(i))){
                sortedArrL.add((Character) mixedArrL.get(i));
            }
        }
        sortedArrL.sort(null);
    }

    public ArrayList getSortedArrL(){

        return sortedArrL;
    }

    static boolean isInteger(Object o) {
        try {
            int i = (int)o;
            return true;
        }
        catch(Exception e) {
            return false;
        }
    }
}
