import java.util.Date;
import java.util.concurrent.TimeUnit;

public class AgeThread extends Thread{
    static Date data;

    public AgeThread(Date dt){
        data = dt;
    }

    public void run() {
        System.out.println("Your age = " + YourAge());
    }

    public static long YourAge() {
        Date today = new Date();
        long diff = today.getTime() - data.getTime();
        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        long years = days / 365;
        return years;
    }

}
