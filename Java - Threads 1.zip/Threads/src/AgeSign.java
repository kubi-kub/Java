/*
import java.util.Arrays;
import datetime;
 */
import org.w3c.dom.CDATASection;

import java.lang.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class AgeSign {
    public static void main(String args[]) throws Exception {

        System.out.println("Enter your birthday (dd.MM.yyyy): ");
        Scanner sc = new Scanner(System.in);
        String i = sc.next();

        Date date = new SimpleDateFormat("dd.MM.yyyy").parse(i);


        AgeThread at = new AgeThread(date);
        at.start();

        SignThread st = new SignThread(date);
        st.start();

        at.join();
        st.join();
        System.out.println("THE END");
    }
}

