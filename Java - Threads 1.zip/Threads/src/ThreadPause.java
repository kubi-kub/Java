public class ThreadPause {
    public void wait(int sec) {
        try {
            Thread.currentThread().sleep(sec*100);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
