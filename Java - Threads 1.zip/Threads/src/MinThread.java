public class MinThread  extends Thread {
    int numbers[];

    public MinThread(int[] nums){
        numbers = nums;
    }

    public void run() {
        System.out.println("Waiting 1 second...");
        wait(1);
        System.out.println("Minimum Value = " + getMinValue(numbers));
    }

    public static int getMinValue(int[] numbers) {
        int minValue = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < minValue) {
                minValue = numbers[i];
            }
        }
        return minValue;
    }

    public void wait(int sec) {
        try {
            Thread.currentThread().sleep(sec*1000);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
