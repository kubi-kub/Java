public class MyThread1 extends Thread{
    public void run() {
        System.out.println("MyThread 1 is running");
    }
}
