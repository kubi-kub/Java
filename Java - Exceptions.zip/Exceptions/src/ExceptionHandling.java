public class ExceptionHandling {
    public static void main(String[] args) {
        String s = "Bolek";
        try{
            System.out.println(s.substring(50));
        }
        catch(StringIndexOutOfBoundsException e) {
            System.out.println("Wystąpił błąd");
        }
    }
}
