import java.util.InputMismatchException;
import java.util.Scanner;
public class ExceptionHandling7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int input;
        System.out.print("How tall are you (in cm)?: ");
        try{
            String s = sc.next();
            input = Integer.parseInt(s);
            if(input < 0){
                throw new MyException1("Not valid hights");
            }
            else {
                System.out.println("You entered: " + input);
                System.out.println("How old are you?");
                input = sc.nextInt();
                if(input < 18) {
                    throw new TooYoungException("You little piece of shit!");
                }
                else {
                    System.out.println("You entered: " + input);
                }
            }
        }
        catch(MyException1 e){
            System.out.println(e.getMessage());
        }
        catch(NumberFormatException e) {
            System.out.println("This is not an integer");
        }
        catch(TooYoungException e) {
            System.out.println(e.getMessage());
        }
        sc.close();
    }
}
