import java.io.*;
public class ExceptionHandling6 {
    public static void main(String[] args) {
        try {
            int buffersize = 10;
            FileReader fr = new FileReader("c:\\Dane\\Test.txt");
            char[] buffer = new char[buffersize];
            int count = fr.read(buffer);
            for (int i = 0; i < count; i++) {
                System.out.print(buffer[i]);
            }
            System.out.println();
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
