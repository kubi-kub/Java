public class ExceptionHandling2 {
    public static void main(String[] args) {
        String b = "1.94";
        try {
            int i = Integer.parseInt(b);
        }
        catch (NumberFormatException e) {
            System.out.println("To nie jest liczba całkowita");
        }
    }
}
