import java.io.*;
public class ExceptionHandling5 {
    public static void main(String[] args) {
        try {
            FileWriter fw = new FileWriter("c:\\Dane\\Test.txt");
            fw.write("Hello");
            fw.close();
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
