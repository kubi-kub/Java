import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input;
        int i = 0;
        int j = 0;
        Boolean ok = Boolean.FALSE;

        while (!ok) {
            System.out.print("Please enter an integer value: ");
            try {
                input = sc.next();
                i = Integer.parseInt(input);
                System.out.println("You entered: " + i);
                ok = Boolean.TRUE;
            } catch (NumberFormatException e) {
                System.out.println("You didn't enter an integer value");
            }
        }
        ok = Boolean.FALSE;
        while (!ok) {
            System.out.print("Please enter second integer value: ");
            try {
                input = sc.next();
                j = Integer.parseInt(input);
                System.out.println("You entered: " + j);
                ok = Boolean.TRUE;
            } catch (NumberFormatException e) {
                System.out.println("You didn't enter an integer value");
            }
        }
        try {
            System.out.println(i / j);
        }
        catch (ArithmeticException e) {
            System.out.println("You cannot divide by 0!");
        }
        finally {
            sc.close();
            System.out.println("The end");
        }
    }
}
