public class ExceptionHandling3 {
    public static void main(String[] args) {
        try {
            int c[] = new int[-2];
        }
        catch (NegativeArraySizeException e) {
            System.out.println("Niedopuszczalny rozmiar tablicy");
        }
    }
}
